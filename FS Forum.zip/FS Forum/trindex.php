<!DOCTYPE Html5>
<html lang="en">
<head>
   <meta charset="UTF-8">
    <title>FS FORUM</title> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

 <style>
body {
  background-image: url('tick.png');
  background-attachment: fixed;
}
</style> 

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    var availableTags = [
      "ActionScript",
      "AppleScript",
	  "HTML",
	  "CSS",
	  "JS",
	  "Jquery",
      "Asp",
      "BASIC",
      "C",
      "C++",
	  "C#",
	  "F#",
      "Clojure",
      "COBOL",
      "ColdFusion",
      "Erlang",
      "Fortran",
      "Groovy",
      "Haskell",
      "Java",
      "JavaScript",
      "Lisp",
      "Perl",
      "PHP",
      "Python",
      "Ruby",
      "Scala",
	  "Programming Languages",
      "Scheme",
	  "Windows",
	  "macOs",
	  "Linux",
	  "iOS",
	  "Android",
	  "Security",
	  "Privacy",
	  "Tracking Protection",
	  "Driver",
	  "Connect",
	  "Extensions",
	  "App",
	  "Install",
	  "Virus",
	  "Covid-19",
	  "Climate Change",
	  "Global Warming",
	  "Time",
	  "Health",
	  "Hardware",
	  "GPU",
	  "CPU",
	  "Camera",
	  "Microphone",
	  "Sound",
	  "Screen",
	  "Plug",
	  "HDD",
	  "SSD",
	  "USB",
	  "Mouse",
	  "Keybord",
	  "Touchpad",
	  "Power",
	  "Charge",
	  "Printer",
	  "VR",
	  "AR",
	  "Forgot",
	  "Philosophy"
	  
    ];
    $( "#tit" ).autocomplete({
      source: availableTags
    });
  } );
  </script>

</head>
<body bgcolor="green"  text="black" link="yellow" vlink="#1409e0" alink="white">
<?php 
	session_set_cookie_params(null, '/', 'localhost', false, true); //SSL sertifikasi alindiginda false olan deger true yapilmalidir.
	session_start();
?>
<div class="container-fluid">
	<div class="header">
		<div class="container">
  <div class="row">
    <div class="col order-last">
		<a href = "#hakkim"><button type="button" class="btn btn-info" position = ""><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Info.svg/50px-Info.svg.png" class="rounded mx-auto d-block" height="50px" width="50px"  alt="info"></button></a>
		<button type="button" class="btn btn-info" position = "" id ="cikb" onclick = "exit()">Çıkış Yap<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/At_sign.svg/145px-At_sign.svg.png" class="rounded mx-auto d-block" height="40px" width="40px"  alt="exit"></button>
		<button type="button" class="btn btn-info" onclick = "go()" position = ""><img class="rounded mx-auto d-block"src="https://upload.wikimedia.org/wikipedia/en/thumb/a/ae/Flag_of_the_United_Kingdom.svg/320px-Flag_of_the_United_Kingdom.svg.png" height="50px" width="50px"  alt="UK"></button>
    </div>
    <div class="col">
    </div>
    <div class="col order-first">
		<a href = "trindex.php">
		<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Solved1.svg/200px-Solved1.svg.png" class="rounded float-start" width = "50px" height = "50px" alt="Logo">
		Fixed - Solved Forum <br> Sorun Değil Çözüm Sunuyoruz
		</a>
    </div>
  </div>
</div>
		</div>
		<hr size="3" width="%100" height="%100">
	</div>
</div>

<div class="container-fluid" id = "addform">



    <form onsubmit="return false;">
        <div class="form-group">
            Çözüm Başlığı*:  <input type="text" id="tit"  placeholder="Çözümün Kısa Tanımı" required> 
        </div>
        <div class="form-group" style="font-size:1vw;">
            <textarea id="comm" rows="10" cols="200" placeholder="Açıklama" required></textarea>  
        </div>
        <div>
            <button type="sumbit" class="btn btn-primary" id = "addf" onclick="formek()" value="Ekle">Ekle
            <button type="reset" class="btn btn-warning"  value="Temizle">Temizle
            <button type="reset" id = "clearAll" class="btn btn-secondary"onclick="temiz()" value="Forumu Temizle">Forumu Temizle    
        </div>
    </form>
</div>

    <div class="container-fluid">
        <form action="">
		<div class="form-group" style="font-size:1vw;">
            <div id="yorum"  >
                <textarea id="yor" rows="100" cols="200" placeholder=""  disabled>
                    
                </textarea>  
            </div>
		</div>
        </form>
    </div>





<div class="container-fluid">
	<div class="footer" id = "hakkim">
		<hr size="5" width="%100" height="%100">
		<img  class="rounded float-start" onclick = "silac()" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8b/Copyleft.svg/1024px-Copyleft.svg.png" height="20px" width="20px" >
		<img  class="rounded float-end" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8b/Copyleft.svg/1024px-Copyleft.svg.png" height="20px" width="20px" >
		<div class="container">
			<div class="row">
				<div class="col order-last">
				<a href = "#addform"><img  class="rounded float-end" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Font_Awesome_5_regular_arrow-alt-circle-up.svg/240px-Font_Awesome_5_regular_arrow-alt-circle-up.svg.png" height="20px" width="20px" ></a>
    </div>
    <div class="col">
		<u><b> Proje Geliştiricileri </b></u><br>
		
    </div>
    <div class="col order-first">
    </div>
  </div>
</div>
		
		
	</div>
</div>

<hr size="3" width="%100" height="%100">

<?php
	if(@$_SESSION['flagl']){
		?>
		<html>
		<body>
		<script>
			document.getElementById("addf").disabled = false;
			var fl = 1;
		</script>
		</body>
		</html>
		<?php
	}
	else{
	?>
		<html>
		<body>
		<script>
			document.getElementById("addf").disabled = true;
			document.getElementById("cikb").innerHTML = "Giriş Yapınız";
			var fl = 0;
		</script>
		</body>
		</html>
		<?php
	}

?>


<script>
	document.getElementById("clearAll").disabled = true;
	
	if(localStorage.getItem("flagel") == 1 || fl == 1){
		document.getElementById("addf").disabled = false;
		document.getElementById("cikb").innerHTML = "Çıkış Yapınız <br><b><h2>@</h2></b>";
	}
    function formek(){
        var title =document.getElementById("tit").value;
        var comment =document.getElementById("comm").value;
		
		if(title != "" && comment != ""){	
			document.getElementById("yor").value +=  title + "\n\t" + comment + "\n";
			localStorage.setItem("forumkayit", document.getElementById("yor").value);
        }
		else{
			
		}
    }
    function temiz(){ //Bu fonksiyon forumu tamamen silmek icin
        document.getElementById("yor").value = "";
		localStorage.setItem("forumkayit", "");
    }
	if(document.getElementById("yor").value == ""){
		temiz(); //Ilk yaziyi farkli hizaliyor bu yuzden ekledim.
	}
	 
	document.getElementById("yor").value = localStorage.getItem("forumkayit");
	function silac(){
		document.getElementById("clearAll").disabled = false;
	}

	function go(){
		localStorage.setItem("flagel", fl);
		window.location.href = "enindex.php";	
	}
	
	
	function exit(){
		<?php
			session_destroy();
		?>
		localStorage.setItem("flagel", 0);
		window.location.href = "index.php";
	}
	
</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
</body>
</html>