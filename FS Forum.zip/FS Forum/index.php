<!DOCTYPE Html5>
<html lang="en">
<head>
   <meta charset="UTF-8">
    <title>FS FORM</title> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">



</head>
<body>
<?php session_start();?>
<center>
<div class="container-fluid">
<hr size="3" width="%100" height="%100">
Login / Giriş
<div>
<div class="container-fluid">
<form class="row g-3" action = ""  method = "POST">
	<div class="col-md-6">
		<label class="form-label">User Name</label>
		<input type="text" class="form-control" name = "gname" placeholder="Kullanıcı Adı" required>
	</div>
	<div class="col-md-6">
		<label class="form-label">Password</label>
		<input type="password" class="form-control" name = "gpaswd" id = "kp" placeholder="Parola" required>
	</div>
	<div class="col-12">
		<label class="form-label">Confirm identity</label><br>
		<button type="submit" class="btn btn-primary mb-3" name = "gir" id = "giris">Giriş Yap</button>
	</div>
	<div class="container-fluid">
		<input class="form-control" type="text" id = "girmsg" placeholder="EN: Please enable cookies because we can't keep login log. TR : Lutfen cookies veya bazi ayarlari acin.Yoksa giris yaptiginiz bilgisini tutamayiz." aria-label="readonly input example" readonly>
	</div>
</form>
</div>

<div class="container-fluid">
<hr size="3" width="%100" height="%100">
Register / Kayıt <br><br>
<div>
<form class="row g-3" action = ""  method = "POST">
	<div class="col-md-6">
    <label  class="form-label" >User Name</label>
    <input type="text" class="form-control"  name = "uname" placeholder = "Kullanıcı Adı" required>
	</div>
	<div class="col-md-6">
    <label  class="form-label" >Password</label>
    <input type="password" class="form-control" name = "paswd" placeholder = "Parola" required>
	</div>
	<div class="col-12">
    <div class="form-check">
      <input class="form-check-input" type="checkbox">
      <label class="form-check-label">
        EN : I promise that I will never forget the password. TR : Parolami unutmiyacağıma söz veriyorum.  
      </label>
    </div>
	</div>
	<div class="col-12">
	<label class="form-label">Register</label><br>
    <button type="submit" name = "reg" id = "kayit" class="btn btn-primary">Kayıt Ol</button>
	</div>
	<div class="container-fluid">
		<input class="form-control" type="text" id = "kaymsg" placeholder="" aria-label="readonly input example" readonly>
	</div>

</form>

<div class="container-fluid">
<hr size="3" width="%100" height="%100">
<div>
</center>

<?php
	function formk(){
		$usrname = $_POST['uname'];
		$parola = $_POST['paswd'];
		$hasun = hash("sha512", $usrname, false);
		$hasp = hash("sha512", $parola, false);
		$flagy = true;
		function dyaz($ka, $sif){
			$usfile = fopen("user_name.txt", "a+") or die("Unable to open file!");
			fwrite($usfile, $ka);
			fwrite($usfile,"\n");
			fclose($usfile);
			$pfile = fopen("password.txt", "a+") or die("Unable to open file!");
			fwrite($pfile, $sif);
			fwrite($pfile,"\n");
			fclose($pfile);
		}
		$usfile = fopen("user_name.txt", "a+") or die("Unable to open file!");
		while (!feof($usfile)){
			$satir = fgets($usfile);
			$satir = preg_replace("/\s.*$/","",$satir);
			if($hasun == $satir){
				fclose($usfile);
				$flagy = false;
				?>
				<html>
				<body>
				<script>
					document.getElementById("kaymsg").value = "EN: Username exists, please register with a new username. TR: Kullanıcı adı mevcut lütfen farklı bir kullanıcı adı ile tekrar deneyiniz.";
				</script>
				</body>
				</html>
				<?php
				break;
			}
		}
		if($flagy){
			dyaz($hasun, $hasp);
			?>
			<html>
			<body>
			<script>
				document.getElementById("kayit").innerHTML = "Registered / Kayit Basarili";
				document.getElementById("kaymsg").value = "EN: The new user has been registered.You can now log in.  TR: Kullanıcı kaydı tamamlandı.Artık giriş yapabilirsiniz.";
				document.getElementById("kayit").disabled = true;
			</script>
			</body>
			</html>
			<?php
		}
		
		
	}
	function login(){
		$flagun = false;
		$flagp = false;
		$_SESSION["LogedIn"]  = false;
		$usrnamel = $_POST['gname'];
		$usrnamel = hash("sha512", $usrnamel, false);
		$parolal = $_POST['gpaswd'];
		$parolal = hash("sha512", $parolal, false);
		$sayac = 0;
		$satir = "0";
		$usnmfile = fopen("user_name.txt", "a+") or die("Unable to open file!");
		while (!feof($usnmfile)){
			$satir = fgets($usnmfile);
			$satir = preg_replace("/\s.*$/","",$satir);
			$sayac += 1;
			if($usrnamel == $satir){
				$flagun = true;
				break;
			}
		}
		fclose($usnmfile);
		if($flagun){
			$psfile = fopen("password.txt", "a+") or die("Unable to open file!");
			for($i= 0; $i < $sayac; $i++){
				$satir = fgets($psfile);
				$satir = preg_replace("/\s.*$/","",$satir);
			}
			
			if($parolal == $satir){
				fclose($psfile);
				$flagp = true;
			}
		}
		if($flagp and $flagun){
			session_regenerate_id(true);
			$_SESSION['flagl']= true;
			?>
			<html>
			<body>
			<script>
				document.getElementById("giris").innerHTML = "Login Succesful / Giris Basarili";
				document.getElementById("girmsg").value = "EN: Login Succesful TR: Giris Basarili yonlendiriliyorsunuz.";
			</script>
			</body>
			</html>
			<?php
			header("Location: trindex.php");
			exit;
		}
		else{
			?>
			<html>
			<body>
			<script>
				document.getElementById("girmsg").value ="EN: You entered incorrect information. Please try again! You promised you wouldn't forget. !  TR: Hatali bilgiler girdiniz.Lutfen tekrar deneyiniz.! Soz vermistiniz unutmiyacaktiniz. !";
			</script>
			</body>
			</html>
			<?php
		}
	}
	if(isset($_POST['reg'])){
		formk();
	}
	if(isset($_POST['gir'])){
		login();
	}


?>

</body>
</html>