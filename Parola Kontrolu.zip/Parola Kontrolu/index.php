<!DOCTYPE Html5>
<html lang="en">
<head>
   <meta charset="UTF-8">
    <title>PASSWORD CHECK</title> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">


</head>
<body>
<br><br><br></div><br><br><br>
<div class="container">
  <div class="row">
	<div class="col"></div>
    <div class="col-md-6">
		<form name="form1" action = ""  method = "POST"> 
		Test Edilecek Parola : <input class="form-control" name = "paswd" type="text" placeholder="">
		<button type="submit" class="btn btn-info" name = "hesap" id= "hesapla" onclick="formk()">Kontrol Et</button>
		<button type="reset" class="btn btn-success">Temizle</button>
		<input class="form-control" name = "result" id="son" type="text" placeholder="Guvenlik zaafiyetleri barindirabileceginden kullandiginiz parolayi girmeyiniz." disabled>
		</form>
	</div>
	<div class="col"><a href="enindex.php" target="_blank"><img src="https://upload.wikimedia.org/wikipedia/en/thumb/a/ae/Flag_of_the_United_Kingdom.svg/320px-Flag_of_the_United_Kingdom.svg.png" class="rounded mx-auto d-block" alt="UK"></a></div>
  </div>
</div>

<?php
	
	function formk(){
		$rakam = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
		$harfb = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "V", "Y", "Z", "Q", "W", "X"];
		$harfk = ["a","b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "v", "y", "z", "q", "w", "x"];
		$ozel = ["#", "@", "'", "~", ";", ":", "/", "\\", ".", ",", "}", "{", "[", "]", "-", "_", "=", ")", "(", "*", "+", "&", "^", "%", "$", "£", "!", "\"", "`", "¬", "|"];
		$parola = $_POST['paswd'];
		$parol = (string)$parola;
		$flag = false;
		$kontrol1 = false; //Rakam
		$kontrol2 = false; //Ozel Karakter
		$kontrol3 = false; //Buyuk harf
		$kontrol4 = false; //Kucuk harf
		if (strlen($parol) > 8 ){
			for($i = 0; $i < strlen($parol); $i++){
				for($j = 0; $j < sizeof($rakam); $j++){
					if($parol[$i] == $rakam[$j]){
						$kontrol1 = true;
						break;
					}
				}
				for($j = 0; $j < sizeof($ozel); $j++){
					if($parol[$i] == $ozel[$j]){
						$kontrol2 = true;
						break;
					}
				}
				for($j = 0; $j < sizeof($harfb); $j++){
					if($parol[$i] == $harfb[$j]){
						$kontrol3 = true;
						break;
					}
				}
				for($j = 0; $j < sizeof($harfk); $j++){
					if($parol[$i] == $harfk[$j]){
						$kontrol4 = true;
						break;
					}
				}
				if($kontrol1 && $kontrol2 && $kontrol3 && $kontrol4){	
					$flag = true;
					echo "Guclu sifre olusturdunuz.<br>Saklamak isterseniz hashlenmis parolaniz: ";
					$hashp = password_hash($parol, algo : PASSWORD_BCRYPT);
					echo $hashp;
					break;
				}
			}
		}
		if(!($flag)){
			echo "Bu parola güvenli değil.Sakın kullanma.";
		}
	}
	if(isset($_POST['hesap'])){
		formk();
	}
	
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
</body>
</html>